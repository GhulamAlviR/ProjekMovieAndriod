package com.example.pedulidigital.data.remote

object ApiKey {
    const val MOVIE_API_KEY = "293dc4ce4df06b15d37a7f0c1d13f716"
}